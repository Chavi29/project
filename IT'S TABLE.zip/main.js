var num = prompt("PLEASE ENTER A NUMBER","");

for (var i = 1 ; i <= 10; i++) {
  document.write("<div>")
  document.write(num + " X " + i + " = " + i*num)
  
    document.write("</div>");
    

  
};